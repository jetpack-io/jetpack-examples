class NotAsyncError(Exception):
    pass
